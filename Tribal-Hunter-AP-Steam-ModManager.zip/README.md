# Tribal Hunter Archipelago (Steam) · ModManager

Import this ZIP directly in TH Mod Manager with binary patch support, then enable the mod. Open the same ZIP separately and copy the three AP support files from `AP Support` beside Tribal Hunter.exe.

The three support files are gm-apclientpp.dll, ap-item.png, and ap-test.ini. See Setup.md for configuring the seed ID and connecting in Settings → Archipelago. Use one archive that matches your game edition.
