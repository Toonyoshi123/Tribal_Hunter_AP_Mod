# Tribal Hunter Archipelago (Steam) · DeltaPatcher

Extract this ZIP. Apply the xdelta patch to a clean copy of data.win using Delta Patcher with checksum validation enabled. Put the patched data.win and the three AP support files beside Tribal Hunter.exe.

The three support files are gm-apclientpp.dll, ap-item.png, and ap-test.ini. See Setup.md for configuring the seed ID and connecting in Settings → Archipelago. Use one archive that matches your game edition.
